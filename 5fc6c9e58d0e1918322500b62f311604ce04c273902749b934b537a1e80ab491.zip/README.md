# 项目简介
此资源包为 [机械动力：航空学](https://modrinth.com/mod/create-aeronautics) 与 [瓦尔基里天空](https://modrinth.com/mod/valkyrien-skies) 及大部分相关模组添加了简体中文翻译。<br>
资源包内也包含一些其他模组的翻译。<br>
**所有可提交至对应仓库的翻译文件均已提交至对应的官方仓库！**<br>
[机械动力：航空学-MC百科界面](https://www.mcmod.cn/class/26350.html)<br>
[瓦尔基里天空-MC百科界面](https://www.mcmod.cn/class/1528.html)

# 支持的模组
## 机械动力：航空学 相关模组
- [[百科](https://www.mcmod.cn/class/26350.html)|[MR](https://modrinth.com/mod/create-aeronautics)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-aeronautics)] 机械动力：航空学（Create: Aeronautics）
- [[百科](https://www.mcmod.cn/class/26344.html)|[MR](https://modrinth.com/mod/sable)|[CF](https://www.curseforge.com/minecraft/mc-mods/sable)] Sable
- [[百科]()|[MR]()|[CF](https://www.curseforge.com/minecraft/mc-mods/create-propulsion-simulated)] 机械动力：推进工程 - 模拟物理（Create Propulsion: Simulated）
- [[百科]()|[MR]()|[CF](https://www.curseforge.com/minecraft/mc-mods/create-aeronautics-sable-mass-view)] Sable：质量显示（Sable: Mass view）
- [[百科]()|[MR]()|[CF](https://www.curseforge.com/minecraft/mc-mods/create-tracks)] 机械动力：履带（Create: Tracks）

## 瓦尔基里天空 相关模组
- [[百科](https://www.mcmod.cn/class/1528.html)|[MR](https://modrinth.com/mod/create-clockwork)|[CF](https://www.curseforge.com/minecraft/mc-mods/valkyrien-skies)] 瓦尔基里天空（Valkyrien Skies）
- [[百科](https://www.mcmod.cn/class/8007.html)|[MR](https://modrinth.com/mod/eureka)|[CF](https://www.curseforge.com/minecraft/mc-mods/eureka-ships)] 瓦尔基里天空：尤里卡（Eureka! Ships! for Valkyrien Skies）
- [[百科](https://www.mcmod.cn/class/13550.html)|[MR](https://modrinth.com/mod/create-clockwork)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-clockwork)] Clockwork
- [[百科](https://www.mcmod.cn/class/16698.html)|[MR](https://modrinth.com/mod/clockwork-additions)|[CF]()] Clockwork Additions
- [[百科](https://www.mcmod.cn/class/15499.html)|[MR](https://modrinth.com/mod/trackwork)|[CF](https://www.curseforge.com/minecraft/mc-mods/trackwork)] 驱动工艺（Trackwork）
- [[百科](https://www.mcmod.cn/class/19600.html)|[MR](https://modrinth.com/mod/create-propulsion)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-propulsion)] 机械动力：推进工程（Create: Propulsion）
- [[百科](https://www.mcmod.cn/class/13218.html)|[MR](https://modrinth.com/mod/interactive)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-interactive)] 机械动力：交互学（Create: Interactive）
- [[百科](https://www.mcmod.cn/class/13891.html)|[MR](https://modrinth.com/mod/vmod)|[CF](https://www.curseforge.com/minecraft/mc-mods/valkyrien-logistics)] Vmod
- [[百科](https://www.mcmod.cn/class/24170.html)|[MR](https://modrinth.com/mod/valkyrien-logistics)|[CF](https://www.curseforge.com/minecraft/mc-mods/valkyrien-logistics)] 瓦尔基里：逻辑仪表（Create: Valkyrien Logistics）
- [[百科](https://www.bilibili.com/video/BV1GJ411x7h7)|[MR](https://modrinth.com/mod/beyond-oxygen)|[CF](https://www.bilibili.com/video/BV1GJ411x7h7)] Beyond Oxygen **（此模组翻译暂未进行校对，谬误较多）**
- [[百科](https://www.mcmod.cn/class/26244.html)|[MR](https://modrinth.com/mod/vs-safe-and-sound)|[CF](https://www.bilibili.com/video/BV1GJ411x7h7)] 瓦尔基里：安然无恙（VS Safe and Sound）

## 同时支持 机械动力：航空学 与 瓦尔基里天空 的模组
- [[百科](https://www.mcmod.cn/class/18675.html)|[MR](https://modrinth.com/mod/drive-by-wire)|[CF](https://www.curseforge.com/minecraft/mc-mods/drive-by-wire)] 线缆控制（Drive-By-Wire）
- [[百科](https://www.mcmod.cn/class/24396.html)|[MR](https://modrinth.com/mod/vs-hose-connectors)|[CF](https://www.curseforge.com/minecraft/mc-mods/vs-hose-connectors)] 瓦尔基里 / Sable：软管接口（VS / Sable Hose Connectors）

## 机械动力 相关模组
- [[百科](https://www.mcmod.cn/class/19259.html)|[MR](https://www.bilibili.com/video/BV1GJ411x7h7)|[CF](https://www.bilibili.com/video/BV1GJ411x7h7)] 思索（Ponder）
- [[百科](https://www.mcmod.cn/class/4178.html)|[MR](https://modrinth.com/mod/flywheel)|[CF](https://www.curseforge.com/minecraft/mc-mods/flywheel)] 飞轮（Flywheel）
- [[百科](https://www.mcmod.cn/class/3437.html)|[MR](https://modrinth.com/mod/createaddition)|[CF](https://www.curseforge.com/minecraft/mc-mods/createaddition)] 机械动力：创想附加（Create Crafts & Additions）
- [[百科](https://www.mcmod.cn/class/11940.html)|[MR](https://modrinth.com/mod/create-tweaked-controllers)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-tweaked-controllers)] 机械动力：高级遥控器（Create: Tweaked Controllers）
- [[百科](https://www.mcmod.cn/class/5189.html)|[MR](https://modrinth.com/mod/create-deco)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-deco)] 机械动力：装饰（Create Deco）
- [[百科](https://www.mcmod.cn/class/11960.html)|[MR](https://modrinth.com/mod/interiors)|[CF](https://www.curseforge.com/minecraft/mc-mods/interiors)] 机械动力：内饰（Create: Interiors）
- [[百科](https://www.mcmod.cn/class/19734.html)|[MR](https://modrinth.com/mod/extra-gauges)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-extra-gauges)] 机械动力：更多仪表（Create: Extra Gauges）
- [[百科](https://www.mcmod.cn/class/18707.html)|[MR](https://modrinth.com/mod/create-big-cannons-advanced-technologies)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-big-cannons-advanced-technologies)] 机械动力：火炮-先进技术（Create Big Cannons: Advanced Technologies）
- [[百科](https://www.mcmod.cn/class/18773.html)|[MR](https://modrinth.com/mod/cbcmodernwarfare)|[CF](https://www.curseforge.com/minecraft/mc-mods/cbc-modern-warfare)] 机械动力：火炮-现代战争（CBC: Modern Warfare）
- [[百科](https://www.mcmod.cn/class/18758.html)|[MR](https://modrinth.com/mod/cbc-nuclear)|[CF](https://www.curseforge.com/minecraft/mc-mods/cbc-nuclear)] 机械动力：火炮-核炮弹（CBC Nuclear）
- [[百科](https://www.mcmod.cn/class/14070.html)|[MR](https://modrinth.com/mod/create-aquatic-ambitions)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-aquatic-ambitions)] 机械动力：瀚海雄心（Create: Aquatic Ambitions）
- [[百科](https://www.mcmod.cn/class/13344.html)|[MR](https://modrinth.com/mod/create-bitterballen)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-bitterballen)] 机械动力：油炸（Create: Bitterballen）
- [[百科](https://www.mcmod.cn/class/14598.html)|[MR](https://modrinth.com/mod/create-deepfried)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-deepfried)] 机械动力：深度油炸（Create: Deepfried）
- [[百科](https://www.mcmod.cn/class/17880.html)|[MR](https://modrinth.com/mod/create-radars)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-radars)] 机械动力：雷达（Create: Radars）
- [[百科](https://www.mcmod.cn/class/19650.html)|[MR](https://modrinth.com/mod/create-stock-bridge)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-stock-bridge)] 机械动力：存储桥接器（Create Stock Bridge）
- [[百科](https://www.mcmod.cn/class/23656.html)|[MR](https://modrinth.com/mod/create-northstar)|[CF](https://www.curseforge.com/minecraft/mc-mods/northstar-redux)] 机械动力：北极星 - 重制版（Create: Northstar - Redux）
- [[百科](https://www.mcmod.cn/class/14360.html)|[MR](https://modrinth.com/mod/numismatics)|[CF](https://www.curseforge.com/minecraft/mc-mods/numismatics)] 机械动力：金融学（Create: Numismatics）
- [[百科](https://www.mcmod.cn/class/18865.html)|[MR](https://modrinth.com/mod/create-security-program)|[CF](https://www.curseforge.com/minecraft/mc-mods/create-security-program)] 机械动力：安全工程（Create: Security Program）

## 其他模组
- [[百科](https://www.mcmod.cn/class/10769.html)|[MR](https://modrinth.com/plugin/advanced-backups)|[CF](https://www.curseforge.com/minecraft/mc-mods/advanced-backups)] 高级备份 Advanced Backups
- [[百科](https://www.mcmod.cn/class/23215.html)|[MR](https://modrinth.com/mod/backport-copper-age)|[CF](https://www.curseforge.com/minecraft/mc-mods/copper-age-backport)] 铜器时代移植版（Copper Age Backport）
- [[百科](https://www.mcmod.cn/class/16400.html)|[MR](https://www.bilibili.com/video/BV1GJ411x7h7)|[CF](https://www.bilibili.com/video/BV1GJ411x7h7)] Mechano

# 未来计划
- Vmod - 帕秋莉手册相关内容
- Beyond Oxygen - 翻译校对
